<?php

namespace App\Http\Controllers;

use App\Models\Berita;
use Illuminate\Http\Request;

class DashboardController extends Controller
{
 public function index(){
   return view('index');

 }

 public function login(){
    return view('login');
 
  }

  public function register(){
    return view('register');
  }


  public function dashboard(){
    $result= Berita::orderBy('created_at','desc')->get();
    return view('admin',[
      'result'=>$result

    ]);
  }

}
